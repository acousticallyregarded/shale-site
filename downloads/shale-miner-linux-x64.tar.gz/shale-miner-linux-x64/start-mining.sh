#!/bin/sh
# Shale miner: run this to start mining on Solana devnet.
# Rewards are TEST tokens with no value.
#
# Edit the settings below, then run:  ./start-mining.sh
# ./shale-miner --help lists every option, ./shale-miner --list-devices your GPUs.

# Your payout wallet: after PAYOUT= paste your Phantom, Solflare or Backpack address
# (copy it from the wallet app; no spaces or quotes).
# Every round you win is credited to this address on-chain, and the rewards add up.
# Claim them on the website: connect this wallet (set to Devnet) and click Claim.
# Leave it empty to credit the mining wallet (wallet.json) itself.
PAYOUT=

# What to mine on: gpu, cpu, both, or empty for automatic (GPUs if any, else the CPU).
MODE=

# How many CPU threads to mine with (CPU mining only). Leave empty for all but one.
WORKERS=

# Which GPUs, by number from --list-devices, for example 0,1. Leave empty for all.
DEVICES=

# GPU dispatch length 1-10: lower keeps the desktop smoother, higher wastes less time.
INTENSITY=

# Pause a GPU at this temperature in degrees C (default 85 where it can be read).
TEMP_LIMIT=

# NVIDIA tuning (Linux; needs root: sudo ./start-mining.sh). Leave empty to change
# nothing. Every value is checked against the card's allowed range, and the original
# settings are restored when the miner stops. Not available on macOS, AMD or Intel GPUs.
#   PL: power limit in watts (200) or percent of the default (70%)
#   LOCK_CCLOCK, LOCK_MCLOCK: lock the core or memory clock (MHz)
#   CCLOCK_OFFSET, MCLOCK_OFFSET: clock offsets in MHz (may be negative)
PL=
LOCK_CCLOCK=
LOCK_MCLOCK=
CCLOCK_OFFSET=
MCLOCK_OFFSET=

# Wallet file. Created next to the miner on first run if it does not exist.
WALLET=wallet.json

cd "$(dirname "$0")" || exit 1
set -- --wallet "$WALLET"
[ -n "$PAYOUT" ] && set -- "$@" --payout "$PAYOUT"
case "$MODE" in
  gpu) set -- "$@" --gpu ;;
  cpu) set -- "$@" --cpu ;;
  both) set -- "$@" --gpu --cpu ;;
esac
[ -n "$WORKERS" ] && set -- "$@" --workers "$WORKERS"
[ -n "$DEVICES" ] && set -- "$@" --devices "$DEVICES"
[ -n "$INTENSITY" ] && set -- "$@" --intensity "$INTENSITY"
[ -n "$TEMP_LIMIT" ] && set -- "$@" --temp-limit "$TEMP_LIMIT"
[ -n "$PL" ] && set -- "$@" --pl "$PL"
[ -n "$LOCK_CCLOCK" ] && set -- "$@" --lock-cclock "$LOCK_CCLOCK"
[ -n "$LOCK_MCLOCK" ] && set -- "$@" --lock-mclock "$LOCK_MCLOCK"
[ -n "$CCLOCK_OFFSET" ] && set -- "$@" --cclock-offset "$CCLOCK_OFFSET"
[ -n "$MCLOCK_OFFSET" ] && set -- "$@" --mclock-offset "$MCLOCK_OFFSET"
exec ./shale-miner "$@"
