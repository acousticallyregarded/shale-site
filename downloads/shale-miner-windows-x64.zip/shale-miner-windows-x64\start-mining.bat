@echo off
rem Shale miner: double-click to start mining on Solana devnet.
rem Rewards are TEST tokens with no value.
rem
rem Edit the settings below, then save and double-click this file.
rem Run "shale-miner.exe --help" for every option, "shale-miner.exe --list-devices" for your GPUs.

rem Your payout wallet: after PAYOUT= paste your Phantom, Solflare or Backpack address
rem (copy it from the wallet app; no spaces or quotes).
rem Every round you win is credited to this address on-chain, and the rewards add up.
rem Claim them on the website: connect this wallet (set to Devnet) and click Claim.
rem Leave it empty to credit the mining wallet (wallet.json) itself.
set PAYOUT=

rem What to mine on: gpu, cpu, both, or empty for automatic (GPUs if any, else the CPU).
set MODE=

rem How many CPU threads to mine with (CPU mining only). Leave empty for all but one.
set WORKERS=

rem Which GPUs, by number from --list-devices, for example 0,1. Leave empty for all.
set DEVICES=

rem GPU dispatch length 1-10: lower keeps the desktop smoother, higher wastes less time.
set INTENSITY=

rem Pause a GPU at this temperature in degrees C (default 85 where it can be read).
set TEMP_LIMIT=

rem NVIDIA tuning. Needs "Run as administrator" (right-click this file). Leave empty to
rem change nothing. Every value is checked against the card's allowed range, and the
rem original settings are restored when the miner stops.
rem   PL: power limit in watts (200) or percent of the default (70%%)
rem   LOCK_CCLOCK, LOCK_MCLOCK: lock the core or memory clock (MHz)
rem   CCLOCK_OFFSET, MCLOCK_OFFSET: clock offsets in MHz (may be negative)
set PL=
set LOCK_CCLOCK=
set LOCK_MCLOCK=
set CCLOCK_OFFSET=
set MCLOCK_OFFSET=

rem Wallet file. Created next to the miner on first run if it does not exist.
set WALLET=wallet.json

cd /d "%~dp0"
set ARGS=--wallet "%WALLET%"
if not "%PAYOUT%"=="" set ARGS=%ARGS% --payout %PAYOUT%
if /i "%MODE%"=="gpu" set ARGS=%ARGS% --gpu
if /i "%MODE%"=="cpu" set ARGS=%ARGS% --cpu
if /i "%MODE%"=="both" set ARGS=%ARGS% --gpu --cpu
if not "%WORKERS%"=="" set ARGS=%ARGS% --workers %WORKERS%
if not "%DEVICES%"=="" set ARGS=%ARGS% --devices %DEVICES%
if not "%INTENSITY%"=="" set ARGS=%ARGS% --intensity %INTENSITY%
if not "%TEMP_LIMIT%"=="" set ARGS=%ARGS% --temp-limit %TEMP_LIMIT%
if not "%PL%"=="" set ARGS=%ARGS% --pl %PL%
if not "%LOCK_CCLOCK%"=="" set ARGS=%ARGS% --lock-cclock %LOCK_CCLOCK%
if not "%LOCK_MCLOCK%"=="" set ARGS=%ARGS% --lock-mclock %LOCK_MCLOCK%
if not "%CCLOCK_OFFSET%"=="" set ARGS=%ARGS% --cclock-offset %CCLOCK_OFFSET%
if not "%MCLOCK_OFFSET%"=="" set ARGS=%ARGS% --mclock-offset %MCLOCK_OFFSET%
shale-miner.exe %ARGS%
pause
