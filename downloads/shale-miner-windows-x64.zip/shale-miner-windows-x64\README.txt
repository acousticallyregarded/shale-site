SHALE MINER
===========

Mines Shale, a new proof-of-work algorithm, in test rounds on Solana devnet.
The first valid solution in each round wins a fixed reward of the test token
"Shale POW Algo" (symbol Shale).

THIS IS A TEST. Devnet tokens have no value and cannot be sold. The miner only
connects to Solana devnet and refuses mainnet.


QUICK START
-----------

First set your payout wallet: open start-mining.bat (Windows) or start-mining.sh
(Linux, Mac) in a text editor and paste your Phantom, Solflare or Backpack
address after PAYOUT= (see YOUR REWARDS below). Then:

Windows:      double-click start-mining.bat
Linux, Mac:   open a terminal in this folder and run  ./start-mining.sh

The miner uses your GPUs if it can, else the CPU. To see your GPUs first:
shale-miner --list-devices

On first run the miner:

  1. creates wallet.json in this folder (your mining wallet, which signs the
     claims and pays their fees),
  2. shows the wallet's address,
  3. asks you to send it a little devnet SOL from https://faucet.solana.com
     (choose Devnet, paste the address, request 1 SOL; it is free),
  4. starts mining by itself once the SOL arrives.

Each winning claim costs about 0.0001 SOL in transaction fees, plus a deposit
that comes back after the claim. The first win credited to a payout wallet
also pays a one-time deposit of under 0.002 SOL for its rewards account.


SETTINGS
--------

Edit start-mining.bat (Windows) or start-mining.sh (Linux, Mac):

  PAYOUT      your Phantom, Solflare or Backpack address: wins are credited
              to it (default: the mining wallet itself)
  MODE        gpu, cpu, both, or empty: GPUs if any can be used, else the CPU
  WORKERS     how many CPU threads to mine with (default: all but one)
  DEVICES     which GPUs, for example 0,1 (default: all)
  INTENSITY   GPU dispatch length 1-10 (default 6)
  TEMP_LIMIT  pause a GPU at this temperature (default 85 C where it can be read)
  PL, LOCK_CCLOCK, LOCK_MCLOCK, CCLOCK_OFFSET, MCLOCK_OFFSET   NVIDIA tuning
  WALLET      which wallet file to use (default: wallet.json)

Or run shale-miner directly with options (shale-miner --help lists them all):

  --wallet FILE        wallet file (created if missing)
  --payout ADDRESS     the wallet your wins are credited to
  --rounds N           stop after N rounds
  --claim-fee-cap L    most lamports one claim may spend on fees
  --session-fee-cap L  most lamports the whole session may spend on fees

Devices:

  --gpu                mine on GPUs
  --cpu                mine on CPU threads (with --gpu: both)
  --workers N          CPU threads (implies --cpu)
  --devices 0,1        which GPUs to use
  --list-devices       list the GPUs, their temperature, power and clocks where
                       the driver reports them, and what can be tuned; then exit
  --intensity 1-10     length of one GPU dispatch: 1 = 10 ms (smoothest desktop),
                       6 = 100 ms (default), 10 = 500 ms (least overhead)
  --batch N            fixed hashes per GPU dispatch instead of --intensity
  --benchmark tiny     measure attempts/s on the chosen devices for 30 s (or
                       --seconds N) without network or wallet

GPUs: NVIDIA, AMD and Intel GPUs mine through Vulkan (or DX12 on Windows),
Apple GPUs through Metal. Before mining, each GPU's kernel is tested against
the CPU reference, and every solution a GPU finds is checked again on the CPU
before it is submitted. A dispatch never runs longer than 1 second.


NVIDIA TUNING
-------------

Nothing is changed unless you ask. Tuning needs administrator rights on
Windows (right-click start-mining.bat, "Run as administrator") or root on
Linux (sudo ./start-mining.sh). It uses the NVIDIA driver's management library
(NVML); there is no tuning on macOS or for AMD, Intel or Apple GPUs yet (those
GPUs still mine, and the miner says tuning is not supported on them).

  --pl W or P%         power limit in watts (--pl 200) or percent of the
                       card's default (--pl 70%)
  --lock-cclock MHz    lock the core clock
  --lock-mclock MHz    lock the memory clock (RTX 30 series and newer)
  --cclock-offset MHz  core clock offset, may be negative (--cclock-offset -200)
  --mclock-offset MHz  memory clock offset in NVML's units (tools that show the
                       effective memory rate may show twice this number)
  --temp-limit C       pause a GPU at C degrees, resume 5 degrees below
  --fan                not supported (see below)
  --reset-gpu          undo what a killed miner left changed, then exit

Each value may be one number for all GPUs, or a list by GPU position with "-"
for no change: --pl 200,-,70%

Safety:

  - Every value is checked against the range the driver reports before
    anything changes; a value outside it is refused and nothing is changed.
  - The original power limit and clock offsets are recorded, and restored
    (and clock locks released) when the miner stops: normally, on Ctrl+C,
    when the window is closed, at log-off or shutdown, on an error or a crash
    inside the miner. The miner prints what it changed and what it restored.
  - If the miner is killed outright (Task Manager, kill -9, power loss), the
    record stays in your temp folder: the next start as administrator restores
    it, or run shale-miner --reset-gpu, or restart the PC (a restart resets
    all of these settings).
  - Tuning needs the GPU temperature to be readable. A GPU pauses at the
    temperature limit (default 85 C); a paused GPU that stays 5 degrees above
    the limit, or stays paused for 5 minutes, stops the miner.
  - --fan is not supported: a fixed fan speed switches the card to manual fan
    control, which would stay in force if the miner were killed, so the card's
    automatic fan control is always left on.
  - Overclocking can make a GPU compute wrong results. Such results fail the
    CPU check and are counted as rejected; lower the offsets if you see any.


YOUR REWARDS
------------

Every round you win is credited on-chain to your payout wallet (PAYOUT in the
start script, or the mining wallet if PAYOUT is empty). Credits add up; nothing
is sent to the wallet until you claim. To claim:

  1. open the Shale website and go to "Claim your Shale",
  2. set your wallet app (Phantom, Solflare or Backpack) to Devnet,
  3. click "Connect wallet" and choose the payout wallet,
  4. the panel shows what you can claim; click "Claim" and approve the
     transaction in the wallet. It needs a little devnet SOL in that wallet
     for the fee (and, the first time, the token account deposit).

The website never asks for a private key or a recovery phrase. Never type
either into any website.

Only the payout wallet can claim. Your mining wallet signs your claims, so
nobody who copies a solution can change where its reward goes. If PAYOUT is
empty, the mining wallet is the payout wallet: import wallet.json into a
wallet app to claim, or run

  shale-rounds withdraw --url https://api.devnet.solana.com --keypair wallet.json
      --program 5XVwNCE51g6fjbjbt9GGk11wLqPaxLojKDGK3qV1o9yn
      --deployment 3mmCZ5tsdmiZyBLUznxk5sE8jwjhhGHgFm9ATjtPktgD

if you have the shale-rounds tool.


YOUR MINING WALLET
------------------

wallet.json holds the private key of your mining wallet. Keep it private and back it
up. Never share it or paste its contents anywhere. The miner only ever prints
the address. The file is a standard Solana keypair, so the Solana CLI and most
wallets can import it.


WHAT YOU SEE
------------

  round N open        a new round started; its challenge cannot be known earlier
  metrics: X attempts/s   one attempt is one full Shale hash (32 memory reads);
                      one line per GPU and for the CPU follows, with temperature,
                      power, core/memory clock and fan where available, and that
                      device's hits, wins, lost races and rejected results
  hit by GPU0 / CPU   your miner found a solution (already checked on the CPU)
  WON (finalized)     your claim was first; the reward is credited to your
                      payout wallet: claim it on the website
  LostRace            another miner's claim reached the program first

After you claim, your test tokens appear in the payout wallet's token account
for the mint 7k2R41gVNxLgx2KDLEGEN4cJ99xTeE5ZtfBQ7acAhkP6 (view it on
https://explorer.solana.com with the cluster set to Devnet).


MACOS NOTE
----------

macOS may block a program downloaded from the internet. If it says the miner
"cannot be opened", run this once in the miner's folder:

  xattr -d com.apple.quarantine shale-miner
